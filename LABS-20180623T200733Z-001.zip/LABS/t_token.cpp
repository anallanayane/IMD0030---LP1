#include <iostream>
#include <sstream>
#include <vector>
#include <cctype>
#include <stdlib.h>
#include <cassert>
#include "tokenizacao.h"

using namespace std;

int main (int argc, char * argv[]) {

	string frase ("eu comi banana na janta");
	
	stringstream ss(frase);
	vector<string> token;

	string temp;
	while (ss >> temp) {
		token.push_back(temp);
	}
	
    cout << "Verificando tokens..." << endl;
    assert(tokenizacao(token));
   
    return EXIT_SUCCESS;
}

	