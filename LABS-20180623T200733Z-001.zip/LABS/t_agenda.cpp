#include <iostream>
#include <string>
#include <memory>
#include <cassert>
#include "agenda.h"

using namespace std;

int main(int argc, char * argv[]) { 
    
    shared_ptr<Contato> aluno = criar_aluno();
    cout << aluno->getNome() << endl; 
    cout << aluno->getTel() << endl; 
    cout << aluno->getEmail() << endl; 

    assert(criar_aluno());

    return 0;
}
