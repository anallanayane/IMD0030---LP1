#ifndef __EXTRAS_H__
#define __EXTRAS_H__

#include <vector>
#include <iterator>
#include "biblioteca.h"

using namespace std;

class Extras{
private:
	vector<vector<int> > matriz;
	vector<string> header;

public:

	/*------------------------------------------FUNCOES EXTRAS SUGERIDAS--------------------------------------*/

	//apaga uma coluna 
	void deletaColuna(string nomeColuna);
	//apaga uma linha
	void deletaLinha(size_t l);
	
	//insere uma coluna no dataframe
	void adicionarColuna(string n, vector<int> v);
	//insere uma linha no dataframe
	void adicionarLinha(vector<int> v);

	//ordena os valores de uma matriz
	void ordenarMatriz();
	//ordena os valores de uma coluna
	void ordenarColuna(string nomeColuna);

	//pesquisa um valor no dataframe e retorna a posicao na linha que o valor se encontra
	vector<int> pesquisar(string col,char e, int x);

	/*-----------------------------------------------FUNCOES EXTRAS EXTRAS-------------------------------------------*/	

	//funcao que edita o valor na posicao indicada da linha e da coluna
	void editarValor(size_t i, size_t j, int valor);
	
	//soma o valor passado em todas as posicoes de uma linha
	void somarValor(int valor, size_t l);
	//soma o valor passado em todas as posicoes de uma coluna
	void somarValorColuna(int valor, string nomeColuna);

	//subtrai o valor em uma linha 
	void subValor(int valor, size_t l);
	//subtrai o valor passado em uma coluna
	void subValorColuna(int valor, string nomeColuna);
	
	//subtrai os valores de uma linha	
	void subLinha(size_t l);
	//subtrai os valores de uma coluna
	void subColuna(string nomeColuna);

	//verifica se o numero que esta na posicao eh par ou impar
	void parOrImpar(size_t i, size_t j);
	//soma todos os valores de uma linha
	void somarLinha(size_t l);
	//multiplica um valor em todas as posicoes de uma coluna
	void multColuna(string nomeColuna, int valor);
	//conta quantos valores tem em uma linha e em uma coluna
	void contar(size_t l, string nomeColuna);
	//retorna a media dos valores de uma linha
	void mediaLinha(size_t l);
	//funcao que verificar maior valor de uma linha
	void valorMaiorLinha(size_t l);
	//funcao que verifica o menor valor de uma linha
	void valorMenorLinha(size_t l);

	~Extras();

};

#endif /* __EXTRAS_H__ */

