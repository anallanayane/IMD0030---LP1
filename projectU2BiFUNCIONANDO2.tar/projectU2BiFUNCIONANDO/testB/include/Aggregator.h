#include <iostream>
#ifndef __AGGREGATOR_H__
#define __AGGREGATOR_H__

#include <vector>	
#include <typeinfo>
#include <algorithm>
#include "Dataframe.h"

using namespace std;

class Aggregator {
	public:
		virtual int operator()(vector<vector<int> > matriz, vector<string> header) = 0;
};


class aggSomaColuna : public Aggregator{
private:
	string nomeColuna = "periodo" ;
public:
	int operator()(vector<vector<int> > matriz, vector<string> header){	
		int soma = 0;
		for(int i = 0; i < header.size(); i++){
			if (nomeColuna == header[i]){
				for(int it : matriz[i]){
					soma += it;			
				}
			}
		}
		cout << endl << "Soma dos valores da Coluna: "; 
		return soma;
	}
};

class aggMediaColuna : public Aggregator{
private:
	string nomeColuna = "id";
public:
	int operator()(vector<vector<int> > matriz, vector<string> header){
		float soma = 0;
		int count = 0;
		float media;
		for(int i = 0; i < header.size(); i++){
			if (nomeColuna == header[i]){
				for (int it : matriz[i]){
					soma += it;
					count++;
					media = soma/count;
				}
			}
		}

		cout << "Media dos valores da Coluna: ";
		return media;
	}
};

class aggMedianaColuna : public Aggregator{
private:
	string nomeColuna = "periodo";
public:
	int operator()(vector<vector<int> > matriz, vector<string> header){
		size_t mediana;
		int i;

		for(i = 0; i < header.size(); i++){
			if (nomeColuna == header[i]){
				if(matriz[i].size ()% 2 != 0){
					mediana = (matriz[i].size() + 1) / 2;
				}
				else{
					mediana = (((matriz[i].size() + 1) / 2) + (matriz[i].size() / 2) / 2);
				}
			}
		}

		cout <<"O valor da mediana esta na posicao ";
		return mediana;
		cout <<" da coluna " << nomeColuna;	
	}
};


class aggValorMaiorColuna: public Aggregator{
private:
	string nomeColuna = "idade";
public:
	int operator()(vector<vector<int> > matriz, vector<string> header){
		vector<int> aux;    
		for(int i = 0; i < header.size(); i++){
			if (nomeColuna == header[i]){
				for(int it : matriz[i]){
					aux.push_back(it);
				}
			}
		}
		cout <<endl;
		cout<<"O maior valor da Coluna eh: ";
		return *max_element(aux.begin(), aux.end()); 
	}
};


class aggValorMenorColuna : public Aggregator{
private:
	string nomeColuna = "id_curso";
public:
	int operator()(vector<vector<int> > matriz, vector<string> header){
		vector<int> aux;    
		for(int i = 0; i < header.size(); i++){
			if (nomeColuna == header[i]){
				for(int it : matriz[i]){
					aux.push_back(it);
				}
			}
		}
		
		cout << endl <<"O menor valor da Coluna eh: ";
		return *min_element(aux.begin(), aux.end()); 
	}
};


#endif /* __AGGREGATOR_H__ */
