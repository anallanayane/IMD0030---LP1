#ifndef __Dataframe_H__
#define __Dataframe_H__

#include <vector>
#include <cstdlib>
#include <string>

using namespace std;

namespace biblioteca{
	
	class Dataframe{
	private:
		vector<vector<int> > matriz;
		vector<string> header;

	public:

		Dataframe() {}

		//retorna uma coluna
		vector<int> getColuna(string nomeColuna);
		//retorna uma linha
		vector<int> getLinha(size_t indice);
		//retorna a matriz
		vector<vector<int>> getMatriz();
		//retorna o cabecalho
		vector<string> getHeader();
		
		//imprimi uma coluna
		void printColuna(string nomeColuna);
		//imprimi uma linha
		void printLinha(size_t l);


		friend ifstream& operator >> (ifstream &in, Dataframe &dt);
		friend ostream& operator << (ostream &out, Dataframe &dt);

		~Dataframe();

	};

}

#endif /* __DATAFRAME_H__ */
