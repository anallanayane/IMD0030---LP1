#include <iostream>
#include <vector>
#include <iomanip>
#include <fstream>
#include <sstream>
#include <typeinfo>
#include <algorithm>
#include <cstdlib>
#include <string>
#include "biblioteca.h"

using namespace std;
using namespace biblioteca;

namespace biblioteca{
	//retorna uma coluna
	vector<int> Dataframe::getColuna(string nomeColuna) {
		for (size_t i = 0; i < header.size(); i++){
			if (nomeColuna == header[i]){
				return matriz[i];
			}
		}
		cout << "Coluna nao encontrada! " <<endl;
		return vector <int> ();
	}
}	
namespace biblioteca{
	//retorna uma linha
	vector<int> Dataframe::getLinha(size_t indice) {
		vector<int> v;

		for (size_t i = 0; i < matriz.size(); i++){
			if (indice < matriz[i].size()){
				v.push_back(matriz[i][indice]);
			}
			else{
				 cout << "Linha nao encontrada!" <<endl;
				 return vector <int> ();
			} 
		}

		return v;
	}
}

namespace biblioteca{
	//retorna uma matriz necessaria para as funções de agregacao
	vector<vector<int>> Dataframe::getMatriz(){
		return matriz;
	}
}
namespace biblioteca{
	//retorna o cabecalho
	vector<string> Dataframe::getHeader(){
		return header;
	}
}
namespace biblioteca{
	//imprimi uma coluna
	void Dataframe::printColuna(string nomeColuna){
		cout << endl <<endl;
		cout << "Coluna " << nomeColuna << ":" <<endl;

		for(size_t i = 0; i < header.size(); i++){
			if (nomeColuna == header[i]){
				cout<<"|"<<header[i]<<"|"<<endl;
				for(int it : matriz[i]){
					cout << it << " " <<endl;
				}
			}
		}
		
	}
}
namespace biblioteca{
	//imprimi uma linha
	void Dataframe::printLinha(size_t l){
		cout <<endl <<endl;
		cout << "Linha " << l + 1 << ":"  <<endl;
		for (vector<int> linha : matriz){
			cout << linha[l] << " ";
		}
	}
}
namespace biblioteca{
	//entrada formatada atraves do operador de insercao
	ifstream& operator >> (ifstream &in, Dataframe &dt){
		string line, valor;
		char delimiter = ',';

		if(!in){
			cerr << "Nao e possivel abrir o arquivo! " <<endl;
			abort();
		}
		getline(in, line);
		stringstream ss(line);

		while(getline(ss, valor, delimiter)){
			dt.header.push_back(valor);
			vector<int> v;
			dt.matriz.push_back(v);
		}

		while (!in.fail()){
			getline(in, line);
			stringstream sss(line);
			int aux = 0;
			while(getline(sss, valor, delimiter)){
				int temp = stoi(valor);
				dt.matriz[aux].push_back(temp);
				aux++;
			}
							
		} 

		return in;
	}
}
namespace biblioteca{
	//saida formata atraves do operador de extracao
	ostream& operator<< (ostream &out, Dataframe &dt){
		cout <<endl;
		for (size_t i = 0; i <dt.header.size(); i++){
			cout << "|" << dt.header[i] <<"|";
		}
		cout << endl; 
			for (size_t i = 0; i < dt.matriz[i].size(); i++){
				for (size_t j = 0; j < dt.matriz.size(); j++){
					cout << dt.matriz[j][i] << " ";
				}
				cout << "\n";
			}

		return out;
	}

	Dataframe::~Dataframe(){}

}