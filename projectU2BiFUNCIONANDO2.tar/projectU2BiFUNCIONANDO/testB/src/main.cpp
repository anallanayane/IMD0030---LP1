#include <iostream>
#include <vector>
#include <iomanip>
#include <fstream>
#include <sstream>
#include <typeinfo>
#include <algorithm>
#include <cstdlib>
#include <string>
#include "biblioteca.h"
#include "Extras.h"

using namespace std;
using namespace biblioteca;


int main(int argc, char const *argv[]) {
	
	Dataframe dt;
	ifstream file;
	ostream *out;
	string str; 
		
	file.open("entrada.csv");
	
	while (file.is_open() && file.good()){
        file >> str;
    }

    file.close();

    file.open("entrada.csv");
    file >> dt;
    file.close();

    (*out) << dt;
   

   	//dt.getColuna("id_curso");
	//dt.getLinha(1);
	//dt.printLinha(1);
	//dt.printColuna("id_curso");
	
	/*------------- FUNCOES EXTRAS SUGERIDAS ----------------*/

	//dt.deletaLinha(2);
	//cout<< endl << endl;
	//(*out) << dt;

	//dt.deletaColuna("matricula");
	//cout<< endl <<endl;
	//(*out) << dt;

    //vector<int> v = {2015,2016,2017,2014,2015};
	//dt.adicionarColuna("ano_ingresso", v);
	//cout<< endl <<endl;
	//(*out) << dt;

	//std::vector<int> v2 = {60, 21, 2013123, 1120, 6, 2013};
	//dt.adicionarLinha(v2);
	//cout<< endl <<endl;
	//(*out) << dt;

    //dt.pesquisar("idade",'>', 20);

    //dt.ordenarMatriz();
	//dt.ordenarColuna("idade");


 	/*----------- FUNCOES EXTRAS EXTRAS ------------------*/
	
	//dt.editarValor(0,1, 999);
	//cout<< endl <<endl;
	//(*out) << dt;

	//dt.somarValor(5,0);
	//cout<< endl <<endl;
	//(*out) << dt;

	//dt.somarValorColuna(5,"id");
	//cout<< endl <<endl;
	//(*out) << dt;

	//dt.subValor(5,0);
	//cout<< endl <<endl;
	//(*out) << dt;

    //dt.subValorColuna(5,"id");
	//cout<< endl <<endl;
	//(*out) << dt;

	//dt.subLinha(0);
	//dt.subColuna("idade");
	//dt.parOrImpar(0,0);
	
	/*-----------------------	AGREGACAO -----------------*/
   	//unique_ptr <Aggregator> agg (new aggSomaLinha());
    //cout << (*agg)((dt).getMatriz()) << endl;

    //unique_ptr <Aggregator> agg (new aggSomaColuna());
    //cout << (*agg)((dt).getMatriz(), (dt).getHeader()) <<endl;

    //unique_ptr <Aggregator> agg (new aggMultColuna());
    //cout << (*agg)((dt).getMatriz(), (dt).getHeader()) <<endl;
	
    //unique_ptr <Aggregator> agg (new aggMediaColuna());
    //cout << (*agg)((dt).getMatriz(), (dt).getHeader()) << endl;
   
   	//unique_ptr <Aggregator> agg (new aggMedianaColuna());
    //cout << (*agg)((dt).getMatriz(), (dt).getHeader()) << endl;

    //unique_ptr <Aggregator> agg (new aggValorMaiorColuna());
    //cout << (*agg)((dt).getMatriz(), (dt).getHeader()) << endl;
    	
   	//unique_ptr <Aggregator> agg (new aggValorMenorColuna());
    //cout << (*agg)((dt).getMatriz(), (dt).getHeader()) <

	return 0;
}