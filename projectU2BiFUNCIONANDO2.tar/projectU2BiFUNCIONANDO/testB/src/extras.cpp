#include <iostream>
#include <vector>
#include <iomanip>
#include <fstream>
#include <sstream>
#include <typeinfo>
#include <algorithm>
#include "biblioteca.h"
#include "Extras.h"

using namespace std;


/*------------------------------------------FUNCOES Extras SUGERIDAS--------------------------------------*/

//apaga uma coluna
void Extras::deletaColuna(string nomeColuna){
	size_t i = 0;
	for(i = 0; i < header.size(); i++){
		if(nomeColuna == header[i]){
			break;
		}
	}
	
	header.erase(header.begin() + i);	
	matriz.erase(matriz.begin() + i);
}	

	//apaga uma linha
void Extras::deletaLinha(size_t l){
	for (vector<int> &linha : matriz){
		if(l < matriz.size()){
     		linha.erase(linha.begin() + l);
  		} 
	}
} 

//adiciona uma coluna no dataframe
void Extras::adicionarColuna(string n, vector<int> v){
	if(v.size() > header.size()){     
		while(v.size() != header.size() ){
			v.pop_back();   
		}
	}
	else if(v.size() < header.size() ){
		while(v.size() != header.size() ){
			v.push_back(0);

		}
	}
	header.push_back(n);
	matriz.push_back(v);
}


//adiciona uma linha ao dataframe
void Extras::adicionarLinha(vector<int> v){
	if(v.size() > matriz.size()){     
		while(v.size() != matriz.size() ){
			v.pop_back();   
		}
	}
	else if(v.size() < matriz.size() ){
		while(v.size() != matriz.size() ){
			v.push_back(0);
		}
	}

	for(size_t i = 0; i < matriz.size(); i++){
		matriz[i].reserve(matriz[i].size()+1);
		matriz[i].push_back(v[i]);
	}

}
	

//funcao de pesquisa que recebe como parametro uma expressao logica
//e retorna o resultado de uma busca correspondente a expressao

vector<int> Extras::pesquisar(string col,char e, int x){
	vector<int> coluna = getColuna(col);
	vector<int> aux = {};
	
	if( e == '>'){
		for(int i : coluna){
			if(i > x){
				aux.push_back(i);
			} 
		}
	}
	
	else if(e == '<'){
		for(int i : coluna){
			if(i < x){
				aux.push_back(i);
			} 
		}
	}
	
	else{
		cout<<"Expressao invalida!"<<endl;
	}

	return aux;   
}

//ordena os valores de uma matriz
void Extras::ordenarMatriz(){
	cout << endl << "Matriz Ordenada: " <<endl;
	for (vector<int> linha : matriz){
		sort(linha.begin(), linha.end()); 
		for(auto i : linha){
			cout << i << " " <<endl;
		}
	} 	
}

//ordena os valores de uma coluna
void Extras::ordenarColuna(string nomeColuna){
	cout << endl << "Coluna Ordenada: " <<endl;
	for(size_t i = 0; i < header.size(); i++){
		if (nomeColuna == header[i]){
			cout<<"|"<<header[i]<<"|"<<endl;
			sort(matriz[i].begin(), matriz[i].end()); 
			for(auto it : matriz[i]){
				cout << it << " " <<endl;
			} 	
		}
	}
}


/*-----------------------------------------------FUNCOES Extras Extras-------------------------------------------*/	

//funcao que edita o valor na posicao indicada da linha e da coluna
void Extras::editarValor(size_t i, size_t j, int valor){
	if (i < matriz.size() && j < matriz[i].size()){
   		matriz[i][j] = valor;
   	}   
}
//soma o valor passado em todas as posicoes de uma linha
void Extras::somarValor(int valor, size_t l){
	for(vector<int> &linha : matriz){
		if (l < linha.size()){
			linha[l] += valor;
		}
	}
}
//soma o valor passado em todas as posicoes de uma coluna
void Extras::somarValorColuna(int valor, string nomeColuna){
	for(size_t i = 0; i < header.size(); i++){
		if (nomeColuna == header[i])
			for(int &coluna :  matriz[i]){
			coluna += valor;
		}
	}
}

//subtrai o valor em uma linha 
void Extras::subValor(int valor, size_t l){
	for(vector<int> &linha : matriz){
		if (l < linha.size()){
			linha[l] = linha[l] - valor;
		}
	}
}
//subtrai o valor passado em uma coluna
void Extras::subValorColuna(int valor, string nomeColuna){
	for(size_t i = 0; i < header.size(); i++){
		if (nomeColuna == header[i]){
			for(int &coluna : matriz[i]){
				coluna -= valor;
			}
		}
	}
}

//subtrai os valores de uma linha
void Extras::subLinha(size_t l){
	int sub = 0;
	for(vector<int> linha : matriz){
			sub -= linha[l];			
	}
	cout << "Subtracao dos valores da Linha: " <<sub <<endl;
}

//subtrai os valores de uma coluna
void Extras::subColuna(string nomeColuna){
	int sub = 0;
	for(size_t i = 0; i < header.size(); i++){
		if (nomeColuna == header[i]){
			for(int it : matriz[i]){
				sub -= it;			
			}
		}
	}
	cout << "Subtracao dos valores da Coluna: " <<sub <<endl;
}

//verifica se o numero que esta na posicao eh par ou impar
void Extras::parOrImpar(size_t i, size_t j){
	for (size_t i = 0; i < matriz.size(); i++){
		for (size_t j = 0; j < matriz.size(); j++){
   		}   
	}
	if(matriz[i][j] % 2 == 0){
		cout << "Numero Par" <<endl;
	}
	else{
		cout << "Numero Impar" <<endl;
	}
}

//soma os valores de uma linha
void Extras::somarLinha(size_t l){
	int soma = 0;
	for(vector<int> linha : matriz){
			soma += linha[l];			
	}
	cout << "Soma dos valores da Linha: " <<soma <<endl;
}

//multiplica o valor passado em todas as posicoes de uma coluna
void Extras::multColuna(string nomeColuna, int valor){	
	for(int i = 0; i < header.size(); i++){
		if (nomeColuna == header[i]){
			for(int &it : matriz[i]){
				it *= valor;			
			}
		}
	}
}
//multiplica o valor passado em todas as posicoes de uma linhq
void Extras::multLinha(size_t l, int valor){
	for(vector<int> &linha : matriz){
		if(l < linha.size()){
			linha[l] *= valor;			
		}
	}
}

//conta a quantidade de elementos de uma linha e de uma coluna
void Extras::contar(size_t l, string nomeColuna){
	int countl = 0;
	int countc = 0;
	int i, j;
	for (i = 0; i < matriz.size(); i++){
		countl++;
	}
	for (j = 0; j < matriz.size(); j++){
		countc++;
	}
		
	cout << "Quantidade de elementos na linha: " << countl++ <<endl;
	cout << "Quantidade de elementos na coluna: " << countc++ <<endl;
}

//calcula a media dos valores de uma linha                             
void Extras::mediaLinha(size_t l){
	float soma = 0;
	int count = 0;
	float media;

	for (vector<int> linha : matriz){
		if(l < linha.size()){
			soma += linha[l];
			count++;
		}

		media = soma/count;
	}

	cout << "Media dos valores da Linha: " << media <<endl;
}


//funcao para verificar maior valor de uma linha
void Extras::valorMaiorLinha(size_t l){
	vector<int> aux;
	for (vector<int> linha : matriz){      
		if (l < linha.size()){
			aux.push_back(linha[l]);
		}   
	}
	
	cout<<"O maior valor da linha eh: "<< *max_element(aux.begin(), aux.end())<<endl; 
}

void Extras::valorMenorLinha(size_t l){
	vector<int> aux;
	for (vector<int> linha : matriz){      
		if (l < linha.size()){
			aux.push_back(linha[l]);
		}   
	}
	
	cout<< endl << "O menor valor da linha eh: "<< *min_element(aux.begin(), aux.end())<<endl; 
}

Extras::~Extras(){}